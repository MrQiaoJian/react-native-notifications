import { Platform } from 'react-native';
import { NativeCommandsSender } from './adapters/NativeCommandsSender';
import { NativeEventsReceiver } from './adapters/NativeEventsReceiver';
import { Commands } from './commands/Commands';
import { EventsRegistry } from './events/EventsRegistry';
import { EventsRegistryIOS } from './events/EventsRegistryIOS';
import { Notification } from './DTO/Notification';
import { UniqueIdProvider } from './adapters/UniqueIdProvider';
import { CompletionCallbackWrapper } from './adapters/CompletionCallbackWrapper';
import { NotificationCategory } from './interfaces/NotificationCategory';
import { NotificationChannel } from './interfaces/NotificationChannel';
import { NotificationsIOS } from './NotificationsIOS';
import { NotificationsAndroid } from './NotificationsAndroid';
import { NotificationFactory } from './DTO/NotificationFactory';
import { NotificationPermissionOptions } from './interfaces/NotificationPermissions';

export class NotificationsRoot {
  public readonly _ios: NotificationsIOS;
  public readonly _android: NotificationsAndroid;

  private readonly notificationFactory: NotificationFactory;
  private readonly nativeEventsReceiver: NativeEventsReceiver;
  private readonly nativeCommandsSender: NativeCommandsSender;
  private readonly commands: Commands;
  private readonly eventsRegistry: EventsRegistry;
  private readonly eventsRegistryIOS: EventsRegistryIOS;
  private readonly uniqueIdProvider: UniqueIdProvider;
  private readonly completionCallbackWrapper: CompletionCallbackWrapper;

  constructor() {
    this.notificationFactory = new NotificationFactory();
    this.nativeEventsReceiver = new NativeEventsReceiver(this.notificationFactory);
    this.nativeCommandsSender = new NativeCommandsSender();
    this.completionCallbackWrapper = new CompletionCallbackWrapper();
    this.uniqueIdProvider = new UniqueIdProvider();
    this.commands = new Commands(
      this.nativeCommandsSender,
      this.uniqueIdProvider,
      this.notificationFactory
    );
    this.eventsRegistry = new EventsRegistry(this.nativeEventsReceiver, this.completionCallbackWrapper);
    this.eventsRegistryIOS = new EventsRegistryIOS(this.nativeEventsReceiver, this.completionCallbackWrapper);

    this._ios = new NotificationsIOS(this.commands, this.eventsRegistryIOS);
    this._android = new NotificationsAndroid(this.commands);
  }

  /**
   * registerRemoteNotifications
   * 显式平台分支：iOS 走 ios 面；android/harmony 走 android 面
   * （harmony 上 ios 面同样可用，若双调用会导致授权请求重复触发）。
   */
  public registerRemoteNotifications(options?: NotificationPermissionOptions) {
    if (Platform.OS === 'ios') {
      this.ios.registerRemoteNotifications(options);
    } else if (Platform.OS === 'android' || (Platform.OS as string) === 'harmony') {
      this.android.registerRemoteNotifications();
    }
  }

  /**
   * postLocalNotification
   */
  public postLocalNotification(notification: Notification, id?: number) {
    return this.commands.postLocalNotification(notification, id);
  }

  /**
   * getInitialNotification
   */
  public getInitialNotification(): Promise<Notification | undefined> {
    return this.commands.getInitialNotification();
  }

  /**
   * setCategories
   */
  public setCategories(categories: NotificationCategory[]) {
    this.commands.setCategories(categories);
  }

  /**
   * cancelLocalNotification
  */
  public cancelLocalNotification(notificationId: number) {
    return this.commands.cancelLocalNotification(notificationId);
  }

  /**
   * removeAllDeliveredNotifications
   */
  public removeAllDeliveredNotifications() {
    return this.commands.removeAllDeliveredNotifications();
  }

  /**
   * isRegisteredForRemoteNotifications
   */
  public isRegisteredForRemoteNotifications(): Promise<boolean> {
    return this.commands.isRegisteredForRemoteNotifications();
  }

  /**
   * setNotificationChannel
   */
  public setNotificationChannel(notificationChannel: NotificationChannel) {
    return this.android.setNotificationChannel(notificationChannel);
  }

  /**
   * Obtain the events registry instance
   */
  public events(): EventsRegistry {
    return this.eventsRegistry;
  }

  /**
   * ios/android getters
   */

  get ios(): NotificationsIOS {
    return this._ios;
  }

  get android(): NotificationsAndroid {
    return this._android;
  }
}
